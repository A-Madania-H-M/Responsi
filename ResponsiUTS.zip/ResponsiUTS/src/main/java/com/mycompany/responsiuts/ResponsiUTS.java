/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.responsiuts;

/**
 *
 * @author Acer
 */
public class ResponsiUTS {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
